#include<iostream>
#include"Controller.h"

using namespace std;

int main()
{
	controller temp;
	temp.m_run();
	return 0;
}