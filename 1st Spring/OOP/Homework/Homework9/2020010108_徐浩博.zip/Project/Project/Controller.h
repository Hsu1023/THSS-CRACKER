#ifndef CONTROLLER_H
#define CONTROLLER_H
#include"Array.h"

class controller
{
private:
	Carray a;
public:
	void m_run();
};

#endif